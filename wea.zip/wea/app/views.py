from django.shortcuts import render
import requests
# Create your views here.

def index(request):
    context={}
    api='360e4bc3865e745ec844bd7ec054ca11'
    city='kochi'

    if request.method == "POST":
        if'city' in request.POST:
            city=request.POST.get("city")

    url=f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api}&units=metric'

    response=requests.get(url)

    data=response.json()

    temp=data['main']['temp']
    temp_min=data['main']['temp_min']
    temp_max=data['main']['temp_max']
    feels=data['main']['feels_like']
    weather=data['weather'][0]['description']

   
    context['temp']=temp
    context['city']=city
    context['feels']=feels
    context['temp_min']=temp_min
    context['temp_max']=temp_max
    context['weather']=weather

    return render(request,'index.html',context)