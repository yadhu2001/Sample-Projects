from django.contrib import admin
from .models import *
# Register your models here.

class Img_display(admin.ModelAdmin):
    list_display=['image','description']

admin.site.register(Img_upload,Img_display)