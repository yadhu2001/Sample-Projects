from django.shortcuts import render,redirect
from . models import *
from django.contrib.auth.forms import UserCreationForm


# Create your views here.

def index(request):
    
    form=UserCreationForm(request.POST)
    if form.is_valid():
        form.save()
        return redirect('home')


    else:
        form=UserCreationForm()
    
    return render(request,'index.html',{'form':form})

def home(request):
    return render(request,'home.html')